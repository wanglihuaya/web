<template>
  <div id="app">
    <index></index>
  </div>
</template>

<script>
import index from './components/index/index'
export default {
  components: {
    index
  }
}
</script>

<style>

</style>
